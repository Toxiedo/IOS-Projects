//
//  file2ViewController.h
//  quran
//
//  Created by Lion User on 15/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface file2ViewController : UIViewController

@end
