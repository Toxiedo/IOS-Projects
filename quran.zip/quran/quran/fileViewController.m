//
//  fileViewController.m
//  quran
//
//  Created by Lion User on 15/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "fileViewController.h"

@interface fileViewController ()

@end

@implementation fileViewController
@synthesize press;

- (IBAction)press:(id)sender {  //  [self performSegueWithIdentifier:@"go" sender:self];    
    
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    CFBundleRef mainbundle = CFBundleGetMainBundle();
    CFURLRef soundfile;
    soundfile = CFBundleCopyResourceURL(mainbundle, (CFStringRef) @"bs" , CFSTR("wav"), NULL);
    UInt32 soundid;
    AudioServicesCreateSystemSoundID(soundfile,&soundid);
    AudioServicesPlaySystemSound(soundid);
    //[press setHidden:YES];
    


}

- (void)viewDidUnload
{
    [self setPress:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
