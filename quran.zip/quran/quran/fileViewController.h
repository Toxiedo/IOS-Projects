//
//  fileViewController.h
//  quran
//
//  Created by Lion User on 15/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>


@interface fileViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *press;

@end
