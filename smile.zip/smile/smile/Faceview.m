//
//  Faceview.m
//  smile
//
//  Created by Lion User on 07/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Faceview.h"

@implementation Faceview

@synthesize scale = _scale;

#define DEFUALT_SCALE 0.90

-(CGFloat)scale
{
    if(!_scale){
        return DEFUALT_SCALE;}
    else{
        return _scale;}
}


-(void) pinch:(UIPinchGestureRecognizer *)gesture
{
    if ((gesture.state == UIGestureRecognizerStateChanged) ||(gesture.state == UIGestureRecognizerStateEnded)) {
        self.scale *= gesture.scale;
        //gesture.scale = 1;
    }
}
-(void)setScale:(CGFloat)scale
{
    if(scale != _scale){
        _scale = scale;
    [self setNeedsDisplay];
    }
}

-(void) setup
{
    self.contentMode = UIViewContentModeRedraw;    
}

-(void)awakeFromNib{
    [self setup];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setup];
    }
    return self;
}

-(void) drawcircleatpoint:(CGPoint)p withradias:(CGFloat)r incon:(CGContextRef)context {
    
    UIGraphicsPushContext(context);
    CGContextBeginPath(context);
    CGContextAddArc(context, p.x, p.y, r, 0, 2*M_PI,YES);
    CGContextStrokePath(context);
    UIGraphicsPopContext();
}


-(void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGPoint midpoint;
    midpoint.x = self.bounds.origin.x + self.bounds.size.width/2;
    midpoint.y = self.bounds.origin.y + self.bounds.size.height/2;
    
    CGFloat size = self.bounds.size.width/2;
    if (self.bounds.size.width/2 > self.bounds.size.height/2) {
        size = self.bounds.size.height/2;
    }
    
    size *=self.scale;
    
    CGContextSetLineWidth(context, 2);
    [[UIColor blueColor]setStroke];
    
    [self drawcircleatpoint:midpoint withradias:size incon:context];
    
    
    #define EYE_X 0.35
    #define EYE_Y 0.35
    #define rad 0.10
    
    CGPoint eyepoint;
    eyepoint.x = midpoint.x - size*EYE_X;
    eyepoint.y = midpoint.y - size*EYE_Y;
    
    [self drawcircleatpoint:eyepoint withradias:size * rad incon:context];
    eyepoint.x += size * EYE_X * 2;
    [self drawcircleatpoint:eyepoint withradias:size * rad incon:context];    
    
}

@end
