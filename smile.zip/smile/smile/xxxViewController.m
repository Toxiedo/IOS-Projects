//
//  xxxViewController.m
//  smile
//
//  Created by Lion User on 07/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "xxxViewController.h"
#import "Faceview.h"

@interface xxxViewController ()
@property (nonatomic , weak) IBOutlet Faceview *fv;
@end

@implementation xxxViewController
@synthesize fv = _fv;

@synthesize happy = _happy;

-(void) setHappy:(int)happy
{
    _happy = happy;
    [self.fv setNeedsDisplay];
}

-(void) setFv:(Faceview *)fv
{
    _fv = fv;
    [self.fv addGestureRecognizer:[[UIPinchGestureRecognizer alloc] initWithTarget:self.fv action:@selector(pinch:)]];
}

- (void)viewDidUnload {
    [self setFv:nil];
    [super viewDidUnload];
}

-(BOOL) shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    return YES;
}


@end
