//
//  yModelController.h
//  calc
//
//  Created by Lion User on 25/08/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class yDataViewController;

@interface yModelController : NSObject <UIPageViewControllerDataSource>

- (yDataViewController *)viewControllerAtIndex:(NSUInteger)index storyboard:(UIStoryboard *)storyboard;
- (NSUInteger)indexOfViewController:(yDataViewController *)viewController;

@end
