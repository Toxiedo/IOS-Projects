//
//  calcTests.h
//  calcTests
//
//  Created by Lion User on 25/08/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface calcTests : SenTestCase

@end
