//
//  calcoobrain.h
//  calcooo
//
//  Created by Lion User on 03/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface calcoobrain : NSObject

-(void)push : (double)num;
-(double)operation:(NSString *)oper;

@end
