//
//  xxxViewController.m
//  calcooo
//
//  Created by Lion User on 01/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "xxxViewController.h"
#import "calcoobrain.h"

@interface xxxViewController ()
@property (nonatomic) BOOL iszero;
@property (nonatomic) calcoobrain* brain;
@end

@implementation xxxViewController
@synthesize display = _display;
@synthesize iszero = _iszero;
@synthesize brain = _brain;


-(calcoobrain*) brain
{
    if( !_brain)  _brain= [[calcoobrain alloc] init ];
    return _brain;
}

- (IBAction)diggetpressed:(UIButton *)sender {
    
    NSString *digit = [sender currentTitle];
    if(self.iszero){    UILabel *mydisplay = [self display];
    NSString *currenttext = [mydisplay text];
    NSString *newtext = [currenttext stringByAppendingString:digit];
    _display.text = newtext;
    }
    else {
        self.display.text = digit;
        self.iszero =YES;
    }
    
}




- (IBAction)operation:(UIButton *)sender {
    if(self.iszero) [self press];
    double res = [self.brain operation:sender.currentTitle];
    NSString* title = [NSString stringWithFormat:@"%g" , res];
    self.display.text = title;
    
}
- (IBAction)press {
    [self.brain push:[self.display.text doubleValue]];
    self.iszero = NO;
}



@end
