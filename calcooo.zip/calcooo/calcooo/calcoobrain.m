//
//  calcoobrain.m
//  calcooo
//
//  Created by Lion User on 03/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "calcoobrain.h"

@interface calcoobrain()

@property (nonatomic , strong) NSMutableArray* numb;

@end


@implementation calcoobrain

@synthesize numb =_numb;

-(NSMutableArray*) numb{
    if(_numb == nil){
        _numb = [[NSMutableArray alloc]init ];
    }
    return _numb;
}

-(void)push :(double)num{
    NSLog(@"islam");
    [self.numb addObject:[NSNumber numberWithDouble:num]];
}


-(double) popnum{
    NSNumber * op = [self.numb lastObject];
    if(op)        
    [self.numb removeLastObject ];
    return [op doubleValue];
}

-(double)operation:(NSString *)oper{
    double res = 0;
    if ([oper isEqualToString:@"+"]) {
        res = [self popnum] + [self popnum] ; 
    }
    if ([oper isEqualToString:@"-"]) {
        res = [self popnum] - [self popnum]; 
    }
    if ([oper isEqualToString:@"/"]) {
        res = [self popnum] / [self popnum]; 
    }
    if ([oper isEqualToString:@"*"]) {
        res = [self popnum] * [self popnum]; 
    }
    return res;
}

@end
