//
//  Ham.m
//  st-game
//
//  Created by Lion User on 12/09/2012.
//  Copyright 2012 __MyCompanyName__. All rights reserved.
//

#import "Ham.h"
#import "AppDelegate.h"
@implementation Ham

+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

@end
