//
//  DoctorsViewController.m
//  hitsball
//
//  Created by Lion User on 14/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "DoctorsViewController.h"
#import <AudioToolbox/AudioToolbox.h>
@interface DoctorsViewController ()

@end

@implementation DoctorsViewController
@synthesize playerball = _playerball;
@synthesize enemyball = _enemyball;
@synthesize start ;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    pos = CGPointMake(5.0, 4.0);
}

- (void)viewDidUnload
{
    [self setPlayerball:nil];
    [self setEnemyball:nil];
    [self setStart:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (IBAction)start:(id)sender {

    [start setHidden:YES];
    randtime = [NSTimer scheduledTimerWithTimeInterval:(0.03) target:self selector:@selector(ontimer) userInfo:nil repeats:YES];
    
    CFBundleRef mainbundle = CFBundleGetMainBundle();
    CFURLRef soundfile;
    soundfile = CFBundleCopyResourceURL(mainbundle, (CFStringRef) @"sound" , CFSTR("wav"), NULL);
    UInt32 soundid;
    AudioServicesCreateSystemSoundID(soundfile,&soundid);
    AudioServicesPlaySystemSound(soundid);
    
    
    
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touc = [[event allTouches]anyObject];
    _playerball.center = [touc locationInView:self.view];
}

-(void)ontimer
{
    [self checkcollection];
    _enemyball.center =CGPointMake(_enemyball.center.x +pos.x, _enemyball.center.y +pos.y);
    if (_enemyball.center.x > 320 || _enemyball.center.x < 0) {
        pos.x = - pos.x;
    }
    
    if (_enemyball.center.y > 480 || _enemyball.center.y < 0) {
        pos.y = - pos.y;
    }    
}

-(void)checkcollection
{
    if (CGRectIntersectsRect(_playerball.frame, _enemyball.frame)) {
        [randtime invalidate];
        [start setHidden:NO];
        pos = CGPointMake(0.0,0.0);
        
        CGRect frame1 = [_enemyball frame];
        frame1.origin.x = 137.0f;
        frame1.origin.y = 326.0f;
        [_enemyball setFrame:frame1];
        
        CGRect frame2 = [_playerball frame];
        frame2.origin.x = 137.0f;
        frame2.origin.y = 20.0f;
        [_playerball setFrame:frame2];
        
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Game Over!" message:@"Try Again To Win" delegate:self cancelButtonTitle:@"Dismiss"otherButtonTitles:nil, nil];
        [alert show];
        
        
    }

}




- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
