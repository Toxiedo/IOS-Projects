//
//  DoctorsViewController.h
//  hitsball
//
//  Created by Lion User on 14/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DoctorsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *playerball;

@property (weak, nonatomic) IBOutlet UIImageView *enemyball;

@property (weak, nonatomic) IBOutlet UIButton *start;


@end
NSTimer *randtime;
CGPoint pos;
CGSize *size;