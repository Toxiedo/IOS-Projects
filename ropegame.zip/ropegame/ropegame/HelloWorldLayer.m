//
//  HelloWorldLayer.m
//  ropegame
//
//  Created by Lion User on 13/09/2012.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"

// Needed to obtain the Navigation Controller
#import "AppDelegate.h"

#pragma mark - HelloWorldLayer

// HelloWorldLayer implementation
@implementation HelloWorldLayer

// Helper class method that creates a Scene with the HelloWorldLayer as the only child.
+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

CCSprite * player;
CCSprite * enemy1;
CCSprite * enemy2;

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super's" return value
	if( (self=[super init]) ) {
		
		// create and initialize a Label
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"Developed By Islam Hamdy" fontName:@"Marker Felt" fontSize:40];

		// ask director for the window size
		CGSize size = [[CCDirector sharedDirector] winSize];
	
		// position the label on the center of the screen
		label.position =  ccp( size.width /2 , size.height-20 );
		
		// add the label as a child to this Layer
		[self addChild: label];
		
        
        //player sitting *******************
        
        player = [CCSprite spriteWithFile:@"Icon.png"];
        player.position = ccp(100,35);
        [self addChild:player];
        
        enemy1 = [CCSprite spriteWithFile:@"playerball.png"];
        enemy1.position = ccp(400,35);
        [self addChild:enemy1];
        
        
        CCMenuItem *item = [CCMenuItemImage itemFromNormalImage:@"playerball.png" selectedImage:@"playerball.png" target:self selector:@selector(dothis)];
    
        CCMenu *men = [CCMenu menuWithItems:item, nil];
        
        [self addChild:men];
        
        
        
        [self schedule:@selector(update:)];
        //[[CCTouchDispatcher sharedDispatcher]addTargetedDelegate:self priority:0 swallowsTouches:YES];

	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}

#pragma mark GameKit delegate

-(void) achievementViewControllerDidFinish:(GKAchievementViewController *)viewController
{
	AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
	[[app navController] dismissModalViewControllerAnimated:YES];
}

-(void) leaderboardViewControllerDidFinish:(GKLeaderboardViewController *)viewController
{
	AppController *app = (AppController*) [[UIApplication sharedApplication] delegate];
	[[app navController] dismissModalViewControllerAnimated:YES];
}

-(void)update:(ccTime)dt
{
    
    float p = enemy1.position.x + 100*dt;
    
    enemy1.position = ccp(p, enemy1.position.y);
    
    CGSize size = [[CCDirector sharedDirector]winSize];
    
    if (enemy1.position.x > size.width) {
        enemy1.position = ccp(-p *dt, enemy1.position.y);  
        //pig.position.x == 130;
        
    }
}
/*
-(BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event{
    CGPoint loc = [touch locationInView:[touch view]];
    CGPoint con_loc = [[CCDirector sharedDirector]convertToGL:loc];
    
    [player stopAllActions];
    id action = 
    return YES;
}
*/
-(void)dothis{
    id action = [CCJumpBy actionWithDuration:3 position:ccp(0, 0) height:200 jumps:1];
    [player runAction:action];
}



@end
