//
//  fileViewController.m
//  paintproject
//
//  Created by Lion User on 15/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "fileViewController.h"

@interface fileViewController ()

@end

@implementation fileViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    CFBundleRef mainbundle = CFBundleGetMainBundle();
    CFURLRef soundfile;
    soundfile = CFBundleCopyResourceURL(mainbundle, (CFStringRef) @"sound" , CFSTR("wav"), NULL);
    UInt32 soundid;
    AudioServicesCreateSystemSoundID(soundfile,&soundid);
    AudioServicesPlaySystemSound(soundid);    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
