//
//  Faceview.h
//  smile
//
//  Created by Lion User on 07/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Faceview : UIView

@property (nonatomic) CGFloat scale;
-(void) pinch :(UIPinchGestureRecognizer *) gesture;
@end
