//
//  DoctorsViewController.m
//  Doctors
//
//  Created by Lion User on 10/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "DoctorsViewController.h"

@interface DoctorsViewController ()

@end

@implementation DoctorsViewController

- (IBAction)flying:(id)sender {
     //[self performSegueWithIdentifier:@"ron" sender:self];
}


- (IBAction)apple:(id)sender {
    [self performSegueWithIdentifier:@"showdia" sender:self];
    
}

- (IBAction)dragons:(id)sender {
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

@end
