//
//  xxxViewController.h
//  smile
//
//  Created by Lion User on 07/09/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface xxxViewController : UIViewController
@property (nonatomic) int happy;



@end
