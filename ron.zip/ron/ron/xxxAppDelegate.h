//
//  xxxAppDelegate.h
//  ron
//
//  Created by Lion User on 27/08/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class xxxViewController;

@interface xxxAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) xxxViewController *viewController;

@end
