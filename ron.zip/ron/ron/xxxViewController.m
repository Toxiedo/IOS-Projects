//
//  xxxViewController.m
//  ron
//
//  Created by Lion User on 27/08/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "xxxViewController.h"

@interface xxxViewController ()

@end

@implementation xxxViewController


-(IBAction)sel{
    lab.text =[[NSString alloc] initWithFormat:@"%.2f",
               5.0];
}

@synthesize alert;
-(IBAction)al:(id)sender{
    NSString *str = [[NSString alloc]
                     initWithFormat:@"Alert , %@" , alert.text];
    UIAlertView *view = [[UIAlertView alloc]
                           initWithTitle:@"facebook"
                         message:str delegate:self cancelButtonTitle:@"cancel" otherButtonTitles: @"facebook", @"twiter", nil];
                     
    [view show];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

@end
